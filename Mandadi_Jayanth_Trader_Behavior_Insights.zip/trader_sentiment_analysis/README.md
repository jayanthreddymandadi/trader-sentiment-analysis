# Trader Sentiment Analysis

## Objective
The objective of this project is to analyze how **Bitcoin market sentiment**
(Fear & Greed Index) influences **trader behavior** using historical trading data.
The goal is to uncover behavioral patterns that help explain how sentiment impacts
trading activity.

---

## Input Data

### 1. Historical Trader Data
- Source: Hyperliquid
- Records: ~211,000 trades
- Key Columns:
  - Execution Price
  - Trade Size
  - Transaction Fee
  - Timestamp (Unix format)
  - Account, Coin, Trade ID

### 2. Bitcoin Fear & Greed Index
- Source: Alternative.me
- Records: ~2,600 daily entries
- Key Columns:
  - Date
  - Sentiment Value
  - Classification (Fear, Greed, Extreme Greed, Neutral)

---

## Data Processing

1. Converted Unix timestamps from trader data into readable date format  
2. Standardized date columns in both datasets  
3. Merged trader data with sentiment data using the **date** column  
4. Final merged dataset contained **184,263 records**  
5. Since explicit profit/loss (PnL) was not available, **transaction fee**
   was used as a proxy metric to represent trader activity and intensity  

---

## Analysis Performed

- Calculated average trader activity under each sentiment category  
- Counted the number of trades per market sentiment  
- Compared trader behavior across Fear, Greed, Extreme Greed, and Neutral phases  
- Visualized trader activity using a boxplot  

---

## Key Results

### Trade Count by Market Sentiment
- Fear: 133,871 trades  
- Greed: 36,289 trades  
- Neutral: 7,141 trades  
- Extreme Greed: 6,962 trades  

### Average Transaction Fee (Proxy Metric)
- Neutral: 1.22  
- Fear: 1.08  
- Extreme Greed: 0.97  
- Greed: 0.67  

---

## Insights

- Trader activity is highest during **Fear** and **Neutral** market conditions  
- **Greed** periods show more cautious trading behavior  
- Extreme sentiment conditions increase variability in trading activity  
- Market sentiment strongly influences trader decision-making  

---

## Output
- Console-based statistical summaries  
- Visualization: **Trader Activity vs Market Sentiment (Boxplot)**  

---

## How to Run

### Folder Structure
trader_sentiment_analysis/
│
├── data/
│ ├── historical_data.csv
│ └── fear_greed_index.csv
│
└── analysis.py

### Install Dependencies
```bash
pip install pandas matplotlib seaborn

### Run the Analysis
python analysis.py

### Tools Used
-Python
-Pandas
-Matplotlib
-Seaborn

### Notes

-Explicit profit and loss (PnL) values were not available in the dataset.
-Transaction fee was used as a proxy metric to analyze trader behavior,
-which is a common approach in behavioral finance analysis.

### Author
-Mandadi Jayanth Reddy
-Aspiring Data Scientist