import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# 1. Load datasets
trades = pd.read_csv("data/historical_data.csv")
sentiment = pd.read_csv("data/fear_greed_index.csv")

print("Trader data shape:", trades.shape)
print("Sentiment data shape:", sentiment.shape)

# 2. Convert date/time columns
trades["Timestamp"] = pd.to_datetime(trades["Timestamp"], unit="ms", errors="coerce")
sentiment["date"] = pd.to_datetime(sentiment["date"], errors="coerce")

trades["date"] = trades["Timestamp"].dt.date
sentiment["date"] = sentiment["date"].dt.date

# 3. Merge datasets
merged = pd.merge(trades, sentiment, on="date", how="inner")

print("Merged data shape:", merged.shape)
print(merged.head())

# 4. Define performance metric
# Using Fee as proxy for trader activity / performance
merged["performance_metric"] = merged["Fee"]

# 5. Analysis: Performance vs Sentiment
print("\nAverage Performance (Fee) by Market Sentiment:")
print(
    merged.groupby("classification")["performance_metric"].mean()
)

# 6. Trade count by Sentiment
print("\nTrade count by Market Sentiment:")
print(
    merged["classification"].value_counts()
)

#7. Box plot of performance metric by sentiment classification(Visualization)
plt.figure(figsize=(7, 5))
sns.boxplot(
    x="classification",
    y="performance_metric",
    data=merged
)
plt.title("Trader Activity vs Market Sentiment")
plt.xlabel("Market Sentiment")
plt.ylabel("Transaction Fee (Proxy Metric)")
plt.tight_layout()
plt.show()


#Bar plot of average activity (for clarity)
avg_activity = merged.groupby("classification")["performance_metric"].mean().reset_index()

plt.figure(figsize=(7, 5))
sns.barplot(
    x="classification",
    y="performance_metric",
    data=avg_activity
)
plt.title("Average Trader Activity by Market Sentiment")
plt.xlabel("Market Sentiment")
plt.ylabel("Average Transaction Fee")
plt.tight_layout()
plt.show()
print("\nAnalysis completed successfully.")